library(dplyr)
library(tidyr)
library(data.table)
set.seed(123)


numeric_cols <- c("salaire", "sondage.distance_travail", 
                  "sondage.valorisation_percue", "sondage.flexibilite_horaires",
                  "sondage.equilibre_perso", "sondage.avantages",
                  "sondage.relation_collegues", "sondage.satisfaction_manager",
                  "sondage.envie_quitter_public")
cat("\nStatistiques descriptives :\n")
setDT(reponse.1)  
summary_stats <- reponse.1[, lapply(.SD, function(x) c(
  Mean = mean(x, na.rm = TRUE),
  Median = median(x, na.rm = TRUE),
  SD = sd(x, na.rm = TRUE),
  Min = min(x, na.rm = TRUE),
  Max = max(x, na.rm = TRUE)
)), .SDcols = numeric_cols]
print(summary_stats)

cat("\nNombre d'employés par métier :\n")
metier_counts=reponse.1[, .N, by = metier][order(-N)]
print(metier_counts)
barplot(metier_counts$N, names.arg = metier_counts$metier, las = 2, cex.names = 0.7, main = "Nombre de répondants par métier")  

stats_envie_quitter =reponse.1[, .(Mean_envie_quitter = mean(sondage.envie_quitter_public, na.rm = TRUE),
               SD_envie_quitter = sd(sondage.envie_quitter_public, na.rm = TRUE)), by = metier][order(Mean_envie_quitter)]
print(stats_envie_quitter)
library(ggplot2)

ggplot(stats_envie_quitter, aes(
  x = reorder(metier, Mean_envie_quitter), 
  y = Mean_envie_quitter
)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  geom_errorbar(
    aes(ymin = Mean_envie_quitter - SD_envie_quitter, 
        ymax = Mean_envie_quitter + SD_envie_quitter),
    width = 0.2, color = "darkgray"
  ) +
  labs(title = "Envie de quitter le secteur public par métier",
       x = "", y = "Moyenne (± écart-type)") +
  theme(
    axis.text.x = element_text(
      angle = 45,       # Rotation à 45 degrés
      hjust = 1,        # Alignement horizontal (1 = droite)
      size = 4.5,         # Taille de police réduite
      margin = margin(t = 4)  # Espace au-dessus des étiquettes
    ),
    plot.margin = unit(c(1, 1, 1, 1), "cm")  # Marge globale du graphique
  )

reponse.1[, .(Mean_envie_quitter = mean(sondage.envie_quitter_public, na.rm = TRUE),
             SD_envie_quitter = sd(sondage.envie_quitter_public, na.rm = TRUE)), by = sexe]

reponse.1[, .(Nombre = .N), by = sexe][order(-Nombre)]

emp_par_hopital <- reponse.1[, .N, by = hopital]
print(emp_par_hopital[order(-N)])
emp_par_hopital[, taille_hopital := fcase(
  N > 100, "Grand",
  N >= 50 & N <= 100, "Moyen",
  N < 50, "Petit"
)]


reponse.1 <- merge(reponse.1, emp_par_hopital[, .(hopital, taille_hopital)], by = "hopital", all.x = TRUE)

ggplot(reponse.1, aes(x = taille_hopital, y = sondage.envie_quitter_public, fill = taille_hopital)) +
  geom_boxplot() +
  theme_minimal() +
  labs(title = "Envie de quitter le secteur public par taille d'hôpital", 
       x = "Taille de l'hôpital", y = "Envie de quitter (1-10)") +
  guides(fill = FALSE)

print(reponse.1[, .(Mean_envie_quitter = mean(sondage.envie_quitter_public, na.rm = TRUE),
               SD_envie_quitter = sd(sondage.envie_quitter_public, na.rm = TRUE)), by = taille_hopital])



model <- lm(sondage.envie_quitter_public ~ 
              salaire  + metier + sexe + taille_hopital+ sondage.distance_travail + sondage.valorisation_percue + 
              sondage.flexibilite_horaires + sondage.equilibre_perso + 
              sondage.avantages + sondage.relation_collegues + 
              sondage.satisfaction_manager,
            data = reponse.1)

# Résumé du modèle
cat("\nRésumé du modèle de régression :\n")
summary(model)

###############################################################################################""""
data=reponse.1
# Par hopital
cat("\nEnvie de quitter par hôpital :\n")
print(data[, .(Mean_envie_quitter = mean(sondage.envie_quitter_public, na.rm = TRUE),
               SD_envie_quitter = sd(sondage.envie_quitter_public, na.rm = TRUE),
               N = .N), by = hopital][order(Mean_envie_quitter)])

# Par metier
cat("\nEnvie de quitter par métier :\n")
print(data[, .(Mean_envie_quitter = mean(sondage.envie_quitter_public, na.rm = TRUE),
               SD_envie_quitter = sd(sondage.envie_quitter_public, na.rm = TRUE),
               N = .N), by = metier][order(Mean_envie_quitter)])

# Par sexe
cat("\nEnvie de quitter par sexe :\n")
print(data[, .(Mean_envie_quitter = mean(sondage.envie_quitter_public, na.rm = TRUE),
               SD_envie_quitter = sd(sondage.envie_quitter_public, na.rm = TRUE),
               N = .N), by = sexe])

# Par taille_hopital (si disponible)
if ("taille_hopital" %in% names(data)) {
  cat("\nEnvie de quitter par taille d'hôpital :\n")
  print(data[, .(Mean_envie_quitter = mean(sondage.envie_quitter_public, na.rm = TRUE),
                 SD_envie_quitter = sd(sondage.envie_quitter_public, na.rm = TRUE),
                 N = .N), by = taille_hopital])
}

# Par tranches de salaire (discrétisation)
data[, salaire_cat := cut(salaire, breaks = c(0, 2000, 4000, Inf), 
                          labels = c("Bas (<2000€)", "Moyen (2000-4000€)", "Haut (>4000€)"))]
cat("\nEnvie de quitter par tranche de salaire :\n")
print(data[, .(Mean_envie_quitter = mean(sondage.envie_quitter_public, na.rm = TRUE),
               SD_envie_quitter = sd(sondage.envie_quitter_public, na.rm = TRUE),
               N = .N), by = salaire_cat])


cat("\nTest ANOVA pour les strates :\n")
anova_metier <- anova(lm(sondage.envie_quitter_public ~ metier, data = data))
anova_sexe <- anova(lm(sondage.envie_quitter_public ~ sexe, data = data))
anova_salaire_cat <- anova(lm(sondage.envie_quitter_public ~ salaire_cat, data = data))
if ("taille_hopital" %in% names(data)) {
  anova_taille <- anova(lm(sondage.envie_quitter_public ~ taille_hopital, data = data))
  cat("ANOVA pour taille_hopital:\n")
  print(anova_taille)
}
cat("ANOVA pour metier:\n")
print(anova_metier)
cat("ANOVA pour sexe:\n")
print(anova_sexe)
cat("ANOVA pour salaire_cat:\n")
print(anova_salaire_cat)

###########################################################################################################





numeric_cols <- c("salaire", "sondage.distance_travail", 
                  "sondage.valorisation_percue", "sondage.flexibilite_horaires",
                  "sondage.equilibre_perso", "sondage.avantages",
                  "sondage.relation_collegues", "sondage.satisfaction_manager",
                  "sondage.envie_quitter_public")
cat("\nStatistiques descriptives :\n")
setDT(reponse.2)  # Convert to data.table
summary_stats <- reponse.2[, lapply(.SD, function(x) c(
  Mean = mean(x, na.rm = TRUE),
  Median = median(x, na.rm = TRUE),
  SD = sd(x, na.rm = TRUE),
  Min = min(x, na.rm = TRUE),
  Max = max(x, na.rm = TRUE)
)), .SDcols = numeric_cols]
print(summary_stats)


hospital_sizes <- c("Hôpital de Issy-les-Moulineaux"="moyen" ,  "Hôpital de Troyes"="moyen" ,              
 "Hôpital de Lorient" ="moyen", "Hôpital de Courbevoie"="moyen", "Hôpital de Six-Fours-les-Plages"="moyen",  "Hôpital de Bondy" ="moyen",               
 "Hôpital de Aubervilliers" ="moyen", "Hôpital de Évry-Courcouronnes"="moyen", "Hôpital de Drancy" ="moyen","Hôpital de Mulhouse"="moyen",             
 "Hôpital de Le Mans" ="moyen", "Hôpital de Nancy" ="moyen", "Hôpital de Cherbourg-en-Cotentin"="moyen",
 "Hôpital de Neuilly-sur-Seine"   ="moyen", "Hôpital de Pessac" ="moyen",  "Hôpital de Saint-Germain-en-Laye"="petit" ,"Hôpital de Beauvais"="petit",           
"Hôpital de Saint-Benoît"="petit",  "Hôpital de Saint-Gratien" ="petit","Hôpital de Choisy-le-Roi"="petit",             
 "Hôpital de Paris" ="grand"  ,   "Hôpital de Lyon"  ="grand",      "Hôpital de Lille"   ="grand",    "Hôpital de Bordeaux"  ="grand", 
"Hôpital de Strasbourg" ="grand"
)
library(dplyr)
reponse.2<- reponse.2 %>%
  mutate(taille_hopital = hospital_sizes[hopital])
data=reponse.2
summary_by_metier <- data %>%
  group_by(metier) %>%
  summarise(
    count = n(),
    envie_quitter = mean(sondage.envie_quitter_public, na.rm = TRUE),
    salaire = mean(salaire, na.rm = TRUE),
    valorisation = mean(sondage.valorisation_percue, na.rm = TRUE),
    flexibilite = mean(sondage.flexibilite_horaires, na.rm = TRUE),
    equilibre = mean(sondage.equilibre_perso, na.rm = TRUE),
    avantages = mean(sondage.avantages, na.rm = TRUE),
    collegues = mean(sondage.relation_collegues, na.rm = TRUE),
    manager = mean(sondage.satisfaction_manager, na.rm = TRUE)
  ) %>%
  mutate(across(where(is.numeric), ~round(., 2)))
print(summary_by_metier)




data <- reponse.2

data <- data %>%
  filter(!is.na(employe.id) & !is.na(hopital) & !is.na(metier)) %>%
  mutate(across(starts_with("sondage."), as.numeric),
         salaire = as.numeric(salaire),
         sondage.distance_travail = as.numeric(sondage.distance_travail))


hospital_sizes <- c(
  "Hôpital de Paris" = "Grand",
  "Hôpital de Évry-Courcouronnes" = "Moyen",
   "Hôpital de Marseille"="Grand",
  "Hôpital de Strasbourg"="Grand",
   "Hôpital de Lille"="Grand",
  "Hôpital de Reims"="Grand",
  "	Hôpital de Bordeaux"="Grand",
  "Hôpital de Le Mans"= "Moyen",
  "Hôpital de Mulhouse"= "Moyen",
  "Hôpital de Nancy"= "Moyen",
  "Hôpital de Aubervilliers"= "Moyen",
  "Hôpital de Courbevoie"= "Moyen",
  "Hôpital de Drancy"= "Moyen",
  "Hôpital de Issy-les-Moulineaux"= "Moyen",
  "Hôpital de Évry-Courcouronnes"= "Moyen",
  "Hôpital de Troyes"= "Moyen",
  "Hôpital de Bondy"=  "Moyen",
  "Hôpital de Six-Fours-les-Plages"= "Moyen",
"Hôpital de Neuilly-sur-Seine"= "Moyen",
  "Hôpital de Lorient" = "Moyen",
  "Hôpital de Pessac" = "Moyen",
  "Hôpital de Neuilly-sur-Seine" = "Moyen",
  "Hôpital de Troyes" = "Moyen",
  "Hôpital de Cherbourg-en-Cotentin" = "Moyen",
  "Hôpital de Bondy" = "Moyen",
  "Hôpital de Six-Fours-les-Plages" = "Petit",
  "Hôpital de Choisy-le-Roi" = "Moyen",
  "Hôpital de Beauvais" = "Moyen",
  "Hôpital de Saint-Germain-en-Laye" = "Moyen",
 "Hôpital de Choisy-le-Roi"= "Petit",
"Hôpital de Beauvais"= "Petit",
"Hôpital de Saint-Germain-en-Laye"= "Petit",
  "Hôpital de Saint-Benoît" = "Petit",
 "Hôpital de Lyon"="Grand",
 "Hôpital de Bordeaux"="Grand",
  "Hôpital de Saint-Gratien" = "Petit"
)

reponse.2 <- reponse.2 %>%
  mutate(taille_hopital = hospital_sizes[hopital])

# Résumé par métier
summary_by_metier <- reponse.2 %>%
  group_by(metier) %>%
  summarise(
    count = n(),
    envie_quitter = mean(sondage.envie_quitter_public, na.rm = TRUE),
    salaire = mean(salaire, na.rm = TRUE),
    valorisation = mean(sondage.valorisation_percue, na.rm = TRUE),
    flexibilite = mean(sondage.flexibilite_horaires, na.rm = TRUE),
    equilibre = mean(sondage.equilibre_perso, na.rm = TRUE),
    avantages = mean(sondage.avantages, na.rm = TRUE),
    collegues = mean(sondage.relation_collegues, na.rm = TRUE),
    manager = mean(sondage.satisfaction_manager, na.rm = TRUE)
  ) %>%
  mutate(across(where(is.numeric), ~round(., 2)))


print(summary_by_metier)
# Résumé par taille d’hôpital
summary_by_size <- reponse.2 %>%
  group_by(taille_hopital) %>%
  summarise(
    count = n(),
    envie_quitter = mean(sondage.envie_quitter_public, na.rm = TRUE),
    valorisation = mean(sondage.valorisation_percue, na.rm = TRUE),
    flexibilite = mean(sondage.flexibilite_horaires, na.rm = TRUE),
    equilibre = mean(sondage.equilibre_perso, na.rm = TRUE),
    avantages = mean(sondage.avantages, na.rm = TRUE),
    collegues = mean(sondage.relation_collegues, na.rm = TRUE),
    manager = mean(sondage.satisfaction_manager, na.rm = TRUE),
    distance=mean(sondage.distance_travail, na.rm = TRUE)
  ) %>%
  mutate(across(where(is.numeric), ~round(., 2)))
print(summary_by_size)


ggplot(summary_by_metier, aes(x = reorder(metier, envie_quitter), y = envie_quitter)) +
  geom_bar(stat = 'identity', fill = '#82ca9d') +
  coord_flip() +
  labs(x = 'Métier', y = "Score moyen d'envie de quitter", title = "Envie de quitter par métier") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, size = 14))

summary_by_size_long <- summary_by_size %>%
  pivot_longer(cols = c(valorisation, flexibilite, equilibre, avantages, collegues, manager),
               names_to = 'variable', values_to = 'score')

ggplot(summary_by_size_long, aes(x = taille_hopital, y = score, fill = variable)) +
  geom_bar(stat = 'identity', position = 'dodge') +
  scale_fill_manual(values = c('#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#ff4d4f', '#d4a5ff'),
                    labels = c('Valorisation', 'Flexibilité', 'Équilibre perso', 'Avantages', 'Collègues', 'Manager')) +
  labs(x = "Taille de l'hôpital", y = 'Score moyen', title = "Scores moyens par taille d'hôpital") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5, size = 14), legend.position = 'bottom')

model <- lm(sondage.envie_quitter_public ~ sondage.valorisation_percue +
              sondage.flexibilite_horaires + sondage.equilibre_perso +
              sondage.avantages + sondage.relation_collegues +
              sondage.satisfaction_manager+sondage.distance_travail + salaire, data = reponse.2)
summary(model)

correlations <- reponse.2 %>%
  select(starts_with("sondage."), -sondage.distance_travail) %>%
  cor(use = "pairwise.complete.obs") %>%
  as.data.frame() %>%
  select(sondage.envie_quitter_public) %>%
  filter(row.names(.) != "sondage.envie_quitter_public") %>%
  arrange(sondage.envie_quitter_public)


print("Corrélations avec sondage.envie_quitter_public :")
print(round(correlations, 2))
summary_model <- summary(model)
print(summary_model)
